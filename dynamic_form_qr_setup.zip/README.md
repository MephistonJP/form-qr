# Dynamic QR code for your Google Form

This QR code is **not** pointed directly at the Google Form. It points to:

    https://mephistonjp.github.io/form-qr/

The `index.html` file hosted there automatically redirects visitors to:

    https://forms.gle/ByAWdjdtGmTz2i7m6

Because the QR image always contains the GitHub Pages address, changing the Google Form URL inside the HTML file does **not** require changing or reprinting the QR image.

## One-time setup (GitHub account: MephistonJP)

1. Go to https://github.com/new and sign in as **MephistonJP**.
2. Repository name: **form-qr** (spelling must match exactly). Set **Public**, then choose **Create repository**. GitHub Pages on GitHub Free requires a public repository.
3. Open the new repository. Choose **Add file → Upload files**, select the supplied `index.html`, then **Commit changes** to the `main` branch.
4. In the repository, open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**. Select **main** and **/(root)**, then save.
6. Open https://mephistonjp.github.io/form-qr/ on your phone or in another browser and check that it takes you to the intended Google Form. GitHub Pages publishing can take several minutes (GitHub documents up to 10 minutes).
7. **Only after step 6 succeeds**, distribute or print `dynamic_form_qr.png` or `dynamic_form_qr.svg`. Test scanning the printed QR with a phone camera before printing a large batch.

## Change the destination later

1. Visit https://github.com/MephistonJP/form-qr/blob/main/index.html
2. Click the pencil icon (**Edit this file**).
3. Change only the quoted URL on this line:

    const DESTINATION_URL = "https://forms.gle/ByAWdjdtGmTz2i7m6";

4. Commit changes on **main**, then revisit https://mephistonjp.github.io/form-qr/ to verify the new destination.
5. Your existing printed QR code stays exactly the same.

## Important

- The QR is **not live** until GitHub Pages has been published at the exact URL above.
- Do not rename/delete the repository or change the GitHub username once you print the QR, unless you retain the existing redirect address. Doing so may break scans.
- The redirect is JavaScript-based (GitHub Pages static hosting cannot issue a server HTTP 302 redirect on its own). Most mobile QR scanners open it fine, but a browser with JavaScript disabled cannot follow it automatically.
- This DIY setup does **not** include scan analytics, a scan limit imposed by a QR-provider service, or guaranteed uptime. It remains subject to GitHub Pages usage limits and service availability.
- The Google Form must remain accessible to its intended respondents under its Google Forms sharing settings.
